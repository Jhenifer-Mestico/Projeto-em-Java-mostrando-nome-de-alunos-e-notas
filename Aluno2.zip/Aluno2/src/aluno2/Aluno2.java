package aluno2;

import javax.swing.JOptionPane;

public class Aluno2 {

    private String nome, rgm;
    private int idade, n, notas[];

    public Aluno2() {
    }

    public Aluno2(String nome, int idade, String rgm, int n) {
        this.nome = nome;
        this.rgm = rgm;
        this.idade = idade;
        this.n = n;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getRgm() {
        return rgm;
    }

    public void setRgm(String rgm) {
        this.rgm = rgm;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public int getN() {
        return n;
    }

    public void setN(int n) {
        this.n = n;
    }

    public int[] getNotas() {
        return notas;
    }

    public void setNotas(int[] notas) {
        this.notas = notas;
    }
    
    public static void main(String[] args) {
      
        Aluno2 objAluno2 = new Aluno2("Jhe", 17, "45674", 4);
        objAluno2.notas = new int[objAluno2.getN()];
        
        for(int i = 0; i < objAluno2.getN(); i++){
           objAluno2.notas[i] = Integer.parseInt(JOptionPane.showInputDialog(null,"Insira a nota", "Notas", JOptionPane.INFORMATION_MESSAGE));
           
        }
        
        //System.out.println("O nome será: " + objAluno2.getNome());
        //System.out.println("A idade é: " + objAluno2.getIdade());
        //System.out.println("O RGM é: " + objAluno2.getRgm());
       
        int matriz[][] = new int[2][2];

     

    for(int i = 0; i < 2; i++){

      for(int j = 0; j < 2; j++){

        //matriz[i][j] = Integer.parseInt(JOptionPane.showInputDialog(null, "insira um valor", "Valor", JOptionPane.INFORMATION_MESSAGE));    

      }

    }

    for(int i = 0; i < 2; i++){

      for(int j = 0; j < 2; j++){

        //System.out.println(" " + matriz[i][j]); 

      }

    }
    
    Aluno2 vetAluno[] = new Aluno2[3];
    vetAluno[0] = new Aluno2("Jheni", 19, "743", 4);
    vetAluno[1] = new Aluno2("Ana", 45, "7564", 4);
    vetAluno[2] = new Aluno2("José", 24, "68495", 4);
    
    for (int i = 0; i < 3; i++){
        System.out.println("Nome: " + vetAluno[i].getNome());
        
    }
        //System.out.println("Dados do Aluno: " + vetAluno[0].getNome());
        //System.out.println("Dados do Aluno: " + vetAluno[0].getIdade());
        //System.out.println("Dados do Aluno: " + vetAluno[0].getRgm());
        
       //System.out.println("Dados do Aluno: " + vetAluno[2].getNome());
       
       //vetAluno[1].setIdade(45);
 
    }
}